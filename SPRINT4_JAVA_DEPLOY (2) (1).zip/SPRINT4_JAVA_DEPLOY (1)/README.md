# Apoia+ — Sprint 4 (Backend)

mvn package && java -jar target/apoia-1.0.0.jar
